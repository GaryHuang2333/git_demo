import java.util.Date;
import java.util.Iterator;
import java.util.List;

public interface a<K, V> {
   String a();

   int b();

   int c();

   long d();

   List<Long> e();

   Long f();

   List<Long> g();

   Date h();

   void i();

   void j();

   V a(K var1);

   V a(K var1, f<K, V> var2);

   void a(K var1, V var2);

   void b(K var1);

   boolean c(K var1);

   Iterator<K> k();

   List<b<K, V>> l();
}
