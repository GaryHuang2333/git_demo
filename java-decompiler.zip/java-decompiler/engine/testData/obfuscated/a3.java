import java.util.concurrent.TimeUnit;

public class a3 {
   private static final a<Integer, Integer> a;
   private static final String[] b;

   private static int a(int param0, boolean param1) {
      // $FF: Couldn't be decompiled
   }

   public static void main(String[] var0) throws Exception {
      boolean var2 = a7.b;
      ax var1 = ax.a();
      System.out.println(b[4]);
      a(42, false);
      System.out.println(var1.e());
      System.out.println(b[5]);
      a(42, true);
      System.out.println(var1.e());
      a();
      System.out.println(b[6]);
      Thread.sleep(5000L);
      System.out.println(b[3]);
      d.b();
      a();
      if (var2) {
         int var3 = ap.c;
         ++var3;
         ap.c = var3;
      }

   }

   private static void a() {
      System.out.println(b[1] + a.c());
      System.out.println(b[0] + a.d());
      System.out.println(b[2] + a.f());
   }

   static {
      int var1;
      int var6;
      char[] var8;
      String[] var10000;
      char[] var10003;
      char[] var10004;
      int var10005;
      int var10006;
      char var10007;
      byte var10008;
      label697: {
         var10000 = new String[7];
         var10003 = "`eA\u0006\u0003\u0015".toCharArray();
         var10005 = var10003.length;
         var1 = 0;
         var10004 = var10003;
         var6 = var10005;
         if (var10005 <= 1) {
            var8 = var10003;
            var10006 = var1;
         } else {
            var10004 = var10003;
            var6 = var10005;
            if (var10005 <= var1) {
               break label697;
            }

            var8 = var10003;
            var10006 = var1;
         }

         while(true) {
            var10007 = var8[var10006];
            switch(var1 % 5) {
            case 0:
               var10008 = 53;
               break;
            case 1:
               var10008 = 22;
               break;
            case 2:
               var10008 = 36;
               break;
            case 3:
               var10008 = 117;
               break;
            default:
               var10008 = 57;
            }

            var8[var10006] = (char)(var10007 ^ var10008);
            ++var1;
            if (var6 == 0) {
               var10006 = var6;
               var8 = var10004;
            } else {
               if (var6 <= var1) {
                  break;
               }

               var8 = var10004;
               var10006 = var1;
            }
         }
      }

      var10000[0] = (new String(var10004)).intern();
      var10003 = "f\u007f^\u0010\u0003\u0015".toCharArray();
      var10005 = var10003.length;
      var1 = 0;
      var10004 = var10003;
      var6 = var10005;
      char[] var2;
      int var3;
      char[] var5;
      char var9;
      byte var10;
      char[] var10001;
      int var10002;
      if (var10005 <= 1) {
         var8 = var10003;
         var10006 = var1;
         var10007 = var10003[var1];
         switch(var1 % 5) {
         case 0:
            var10008 = 53;
            break;
         case 1:
            var10008 = 22;
            break;
         case 2:
            var10008 = 36;
            break;
         case 3:
            var10008 = 117;
            break;
         default:
            var10008 = 57;
         }
      } else {
         var10004 = var10003;
         var6 = var10005;
         if (var10005 <= var1) {
            label740: {
               var10000[1] = (new String(var10003)).intern();
               var10003 = "}\u007fPXkTbAO\u0019".toCharArray();
               var10005 = var10003.length;
               var1 = 0;
               var10004 = var10003;
               var6 = var10005;
               if (var10005 <= 1) {
                  var8 = var10003;
                  var10006 = var1;
               } else {
                  var10004 = var10003;
                  var6 = var10005;
                  if (var10005 <= var1) {
                     break label740;
                  }

                  var8 = var10003;
                  var10006 = var1;
               }

               while(true) {
                  var10007 = var8[var10006];
                  switch(var1 % 5) {
                  case 0:
                     var10008 = 53;
                     break;
                  case 1:
                     var10008 = 22;
                     break;
                  case 2:
                     var10008 = 36;
                     break;
                  case 3:
                     var10008 = 117;
                     break;
                  default:
                     var10008 = 57;
                  }

                  var8[var10006] = (char)(var10007 ^ var10008);
                  ++var1;
                  if (var6 == 0) {
                     var10006 = var6;
                     var8 = var10004;
                  } else {
                     if (var6 <= var1) {
                        break;
                     }

                     var8 = var10004;
                     var10006 = var1;
                  }
               }
            }

            var10000[2] = (new String(var10004)).intern();
            var10003 = "gcJ\u001bP[q\u0004\u0016XV~AX\\C\u007fG\u0001PZx\n[\u0017".toCharArray();
            var10005 = var10003.length;
            var1 = 0;
            var10004 = var10003;
            var6 = var10005;
            if (var10005 <= 1) {
               var8 = var10003;
               var10006 = var1;
               var10007 = var10003[var1];
               switch(var1 % 5) {
               case 0:
                  var10008 = 53;
                  break;
               case 1:
                  var10008 = 22;
                  break;
               case 2:
                  var10008 = 36;
                  break;
               case 3:
                  var10008 = 117;
                  break;
               default:
                  var10008 = 57;
               }
            } else {
               var10004 = var10003;
               var6 = var10005;
               if (var10005 <= var1) {
                  label808: {
                     var10000[3] = (new String(var10003)).intern();
                     var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~K\u0000M\u0015uE\u0016QP,".toCharArray();
                     var10005 = var10003.length;
                     var1 = 0;
                     var10004 = var10003;
                     var6 = var10005;
                     if (var10005 <= 1) {
                        var8 = var10003;
                        var10006 = var1;
                     } else {
                        var10004 = var10003;
                        var6 = var10005;
                        if (var10005 <= var1) {
                           break label808;
                        }

                        var8 = var10003;
                        var10006 = var1;
                     }

                     while(true) {
                        var10007 = var8[var10006];
                        switch(var1 % 5) {
                        case 0:
                           var10008 = 53;
                           break;
                        case 1:
                           var10008 = 22;
                           break;
                        case 2:
                           var10008 = 36;
                           break;
                        case 3:
                           var10008 = 117;
                           break;
                        default:
                           var10008 = 57;
                        }

                        var8[var10006] = (char)(var10007 ^ var10008);
                        ++var1;
                        if (var6 == 0) {
                           var10006 = var6;
                           var8 = var10004;
                        } else {
                           if (var6 <= var1) {
                              break;
                           }

                           var8 = var10004;
                           var10006 = var1;
                        }
                     }
                  }

                  var10000[4] = (new String(var10004)).intern();
                  var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~\u0004\u0016XV~AO".toCharArray();
                  var10005 = var10003.length;
                  var1 = 0;
                  var10004 = var10003;
                  var6 = var10005;
                  if (var10005 <= 1) {
                     var8 = var10003;
                     var10006 = var1;
                     var10007 = var10003[var1];
                     switch(var1 % 5) {
                     case 0:
                        var10008 = 53;
                        break;
                     case 1:
                        var10008 = 22;
                        break;
                     case 2:
                        var10008 = 36;
                        break;
                     case 3:
                        var10008 = 117;
                        break;
                     default:
                        var10008 = 57;
                     }
                  } else {
                     var10004 = var10003;
                     var6 = var10005;
                     if (var10005 <= var1) {
                        label876: {
                           var10000[5] = (new String(var10003)).intern();
                           var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                           var10005 = var10003.length;
                           var1 = 0;
                           var10004 = var10003;
                           var6 = var10005;
                           if (var10005 <= 1) {
                              var8 = var10003;
                              var10006 = var1;
                           } else {
                              var10004 = var10003;
                              var6 = var10005;
                              if (var10005 <= var1) {
                                 break label876;
                              }

                              var8 = var10003;
                              var10006 = var1;
                           }

                           while(true) {
                              var10007 = var8[var10006];
                              switch(var1 % 5) {
                              case 0:
                                 var10008 = 53;
                                 break;
                              case 1:
                                 var10008 = 22;
                                 break;
                              case 2:
                                 var10008 = 36;
                                 break;
                              case 3:
                                 var10008 = 117;
                                 break;
                              default:
                                 var10008 = 57;
                              }

                              var8[var10006] = (char)(var10007 ^ var10008);
                              ++var1;
                              if (var6 == 0) {
                                 var10006 = var6;
                                 var8 = var10004;
                              } else {
                                 if (var6 <= var1) {
                                    break;
                                 }

                                 var8 = var10004;
                                 var10006 = var1;
                              }
                           }
                        }

                        var10000[6] = (new String(var10004)).intern();
                        b = var10000;
                        var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                        var10002 = var2.length;
                        var1 = 0;
                        var10001 = var2;
                        var3 = var10002;
                        if (var10002 <= 1) {
                           var5 = var2;
                           var6 = var1;
                        } else {
                           var10001 = var2;
                           var3 = var10002;
                           if (var10002 <= var1) {
                              a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                              return;
                           }

                           var5 = var2;
                           var6 = var1;
                        }

                        while(true) {
                           var9 = var5[var6];
                           switch(var1 % 5) {
                           case 0:
                              var10 = 53;
                              break;
                           case 1:
                              var10 = 22;
                              break;
                           case 2:
                              var10 = 36;
                              break;
                           case 3:
                              var10 = 117;
                              break;
                           default:
                              var10 = 57;
                           }

                           var5[var6] = (char)(var9 ^ var10);
                           ++var1;
                           if (var3 == 0) {
                              var6 = var3;
                              var5 = var10001;
                           } else {
                              if (var3 <= var1) {
                                 a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                 return;
                              }

                              var5 = var10001;
                              var6 = var1;
                           }
                        }
                     }

                     var8 = var10003;
                     var10006 = var1;
                     var10007 = var10003[var1];
                     switch(var1 % 5) {
                     case 0:
                        var10008 = 53;
                        break;
                     case 1:
                        var10008 = 22;
                        break;
                     case 2:
                        var10008 = 36;
                        break;
                     case 3:
                        var10008 = 117;
                        break;
                     default:
                        var10008 = 57;
                     }
                  }

                  while(true) {
                     while(true) {
                        var8[var10006] = (char)(var10007 ^ var10008);
                        ++var1;
                        if (var6 == 0) {
                           var10006 = var6;
                           var8 = var10004;
                           var10007 = var10004[var6];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        } else {
                           if (var6 <= var1) {
                              label984: {
                                 var10000[5] = (new String(var10004)).intern();
                                 var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                 var10005 = var10003.length;
                                 var1 = 0;
                                 var10004 = var10003;
                                 var6 = var10005;
                                 if (var10005 <= 1) {
                                    var8 = var10003;
                                    var10006 = var1;
                                 } else {
                                    var10004 = var10003;
                                    var6 = var10005;
                                    if (var10005 <= var1) {
                                       break label984;
                                    }

                                    var8 = var10003;
                                    var10006 = var1;
                                 }

                                 while(true) {
                                    var10007 = var8[var10006];
                                    switch(var1 % 5) {
                                    case 0:
                                       var10008 = 53;
                                       break;
                                    case 1:
                                       var10008 = 22;
                                       break;
                                    case 2:
                                       var10008 = 36;
                                       break;
                                    case 3:
                                       var10008 = 117;
                                       break;
                                    default:
                                       var10008 = 57;
                                    }

                                    var8[var10006] = (char)(var10007 ^ var10008);
                                    ++var1;
                                    if (var6 == 0) {
                                       var10006 = var6;
                                       var8 = var10004;
                                    } else {
                                       if (var6 <= var1) {
                                          break;
                                       }

                                       var8 = var10004;
                                       var10006 = var1;
                                    }
                                 }
                              }

                              var10000[6] = (new String(var10004)).intern();
                              b = var10000;
                              var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                              var10002 = var2.length;
                              var1 = 0;
                              var10001 = var2;
                              var3 = var10002;
                              if (var10002 <= 1) {
                                 var5 = var2;
                                 var6 = var1;
                              } else {
                                 var10001 = var2;
                                 var3 = var10002;
                                 if (var10002 <= var1) {
                                    a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                    return;
                                 }

                                 var5 = var2;
                                 var6 = var1;
                              }

                              while(true) {
                                 var9 = var5[var6];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10 = 53;
                                    break;
                                 case 1:
                                    var10 = 22;
                                    break;
                                 case 2:
                                    var10 = 36;
                                    break;
                                 case 3:
                                    var10 = 117;
                                    break;
                                 default:
                                    var10 = 57;
                                 }

                                 var5[var6] = (char)(var9 ^ var10);
                                 ++var1;
                                 if (var3 == 0) {
                                    var6 = var3;
                                    var5 = var10001;
                                 } else {
                                    if (var3 <= var1) {
                                       a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                       return;
                                    }

                                    var5 = var10001;
                                    var6 = var1;
                                 }
                              }
                           }

                           var8 = var10004;
                           var10006 = var1;
                           var10007 = var10004[var1];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        }
                     }
                  }
               }

               var8 = var10003;
               var10006 = var1;
               var10007 = var10003[var1];
               switch(var1 % 5) {
               case 0:
                  var10008 = 53;
                  break;
               case 1:
                  var10008 = 22;
                  break;
               case 2:
                  var10008 = 36;
                  break;
               case 3:
                  var10008 = 117;
                  break;
               default:
                  var10008 = 57;
               }
            }

            while(true) {
               while(true) {
                  var8[var10006] = (char)(var10007 ^ var10008);
                  ++var1;
                  if (var6 == 0) {
                     var10006 = var6;
                     var8 = var10004;
                     var10007 = var10004[var6];
                     switch(var1 % 5) {
                     case 0:
                        var10008 = 53;
                        break;
                     case 1:
                        var10008 = 22;
                        break;
                     case 2:
                        var10008 = 36;
                        break;
                     case 3:
                        var10008 = 117;
                        break;
                     default:
                        var10008 = 57;
                     }
                  } else {
                     if (var6 <= var1) {
                        label1119: {
                           var10000[3] = (new String(var10004)).intern();
                           var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~K\u0000M\u0015uE\u0016QP,".toCharArray();
                           var10005 = var10003.length;
                           var1 = 0;
                           var10004 = var10003;
                           var6 = var10005;
                           if (var10005 <= 1) {
                              var8 = var10003;
                              var10006 = var1;
                           } else {
                              var10004 = var10003;
                              var6 = var10005;
                              if (var10005 <= var1) {
                                 break label1119;
                              }

                              var8 = var10003;
                              var10006 = var1;
                           }

                           while(true) {
                              var10007 = var8[var10006];
                              switch(var1 % 5) {
                              case 0:
                                 var10008 = 53;
                                 break;
                              case 1:
                                 var10008 = 22;
                                 break;
                              case 2:
                                 var10008 = 36;
                                 break;
                              case 3:
                                 var10008 = 117;
                                 break;
                              default:
                                 var10008 = 57;
                              }

                              var8[var10006] = (char)(var10007 ^ var10008);
                              ++var1;
                              if (var6 == 0) {
                                 var10006 = var6;
                                 var8 = var10004;
                              } else {
                                 if (var6 <= var1) {
                                    break;
                                 }

                                 var8 = var10004;
                                 var10006 = var1;
                              }
                           }
                        }

                        var10000[4] = (new String(var10004)).intern();
                        var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~\u0004\u0016XV~AO".toCharArray();
                        var10005 = var10003.length;
                        var1 = 0;
                        var10004 = var10003;
                        var6 = var10005;
                        if (var10005 <= 1) {
                           var8 = var10003;
                           var10006 = var1;
                           var10007 = var10003[var1];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        } else {
                           var10004 = var10003;
                           var6 = var10005;
                           if (var10005 <= var1) {
                              label1187: {
                                 var10000[5] = (new String(var10003)).intern();
                                 var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                 var10005 = var10003.length;
                                 var1 = 0;
                                 var10004 = var10003;
                                 var6 = var10005;
                                 if (var10005 <= 1) {
                                    var8 = var10003;
                                    var10006 = var1;
                                 } else {
                                    var10004 = var10003;
                                    var6 = var10005;
                                    if (var10005 <= var1) {
                                       break label1187;
                                    }

                                    var8 = var10003;
                                    var10006 = var1;
                                 }

                                 while(true) {
                                    var10007 = var8[var10006];
                                    switch(var1 % 5) {
                                    case 0:
                                       var10008 = 53;
                                       break;
                                    case 1:
                                       var10008 = 22;
                                       break;
                                    case 2:
                                       var10008 = 36;
                                       break;
                                    case 3:
                                       var10008 = 117;
                                       break;
                                    default:
                                       var10008 = 57;
                                    }

                                    var8[var10006] = (char)(var10007 ^ var10008);
                                    ++var1;
                                    if (var6 == 0) {
                                       var10006 = var6;
                                       var8 = var10004;
                                    } else {
                                       if (var6 <= var1) {
                                          break;
                                       }

                                       var8 = var10004;
                                       var10006 = var1;
                                    }
                                 }
                              }

                              var10000[6] = (new String(var10004)).intern();
                              b = var10000;
                              var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                              var10002 = var2.length;
                              var1 = 0;
                              var10001 = var2;
                              var3 = var10002;
                              if (var10002 <= 1) {
                                 var5 = var2;
                                 var6 = var1;
                              } else {
                                 var10001 = var2;
                                 var3 = var10002;
                                 if (var10002 <= var1) {
                                    a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                    return;
                                 }

                                 var5 = var2;
                                 var6 = var1;
                              }

                              while(true) {
                                 var9 = var5[var6];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10 = 53;
                                    break;
                                 case 1:
                                    var10 = 22;
                                    break;
                                 case 2:
                                    var10 = 36;
                                    break;
                                 case 3:
                                    var10 = 117;
                                    break;
                                 default:
                                    var10 = 57;
                                 }

                                 var5[var6] = (char)(var9 ^ var10);
                                 ++var1;
                                 if (var3 == 0) {
                                    var6 = var3;
                                    var5 = var10001;
                                 } else {
                                    if (var3 <= var1) {
                                       a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                       return;
                                    }

                                    var5 = var10001;
                                    var6 = var1;
                                 }
                              }
                           }

                           var8 = var10003;
                           var10006 = var1;
                           var10007 = var10003[var1];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        }

                        while(true) {
                           while(true) {
                              var8[var10006] = (char)(var10007 ^ var10008);
                              ++var1;
                              if (var6 == 0) {
                                 var10006 = var6;
                                 var8 = var10004;
                                 var10007 = var10004[var6];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10008 = 53;
                                    break;
                                 case 1:
                                    var10008 = 22;
                                    break;
                                 case 2:
                                    var10008 = 36;
                                    break;
                                 case 3:
                                    var10008 = 117;
                                    break;
                                 default:
                                    var10008 = 57;
                                 }
                              } else {
                                 if (var6 <= var1) {
                                    label1295: {
                                       var10000[5] = (new String(var10004)).intern();
                                       var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                       var10005 = var10003.length;
                                       var1 = 0;
                                       var10004 = var10003;
                                       var6 = var10005;
                                       if (var10005 <= 1) {
                                          var8 = var10003;
                                          var10006 = var1;
                                       } else {
                                          var10004 = var10003;
                                          var6 = var10005;
                                          if (var10005 <= var1) {
                                             break label1295;
                                          }

                                          var8 = var10003;
                                          var10006 = var1;
                                       }

                                       while(true) {
                                          var10007 = var8[var10006];
                                          switch(var1 % 5) {
                                          case 0:
                                             var10008 = 53;
                                             break;
                                          case 1:
                                             var10008 = 22;
                                             break;
                                          case 2:
                                             var10008 = 36;
                                             break;
                                          case 3:
                                             var10008 = 117;
                                             break;
                                          default:
                                             var10008 = 57;
                                          }

                                          var8[var10006] = (char)(var10007 ^ var10008);
                                          ++var1;
                                          if (var6 == 0) {
                                             var10006 = var6;
                                             var8 = var10004;
                                          } else {
                                             if (var6 <= var1) {
                                                break;
                                             }

                                             var8 = var10004;
                                             var10006 = var1;
                                          }
                                       }
                                    }

                                    var10000[6] = (new String(var10004)).intern();
                                    b = var10000;
                                    var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                                    var10002 = var2.length;
                                    var1 = 0;
                                    var10001 = var2;
                                    var3 = var10002;
                                    if (var10002 <= 1) {
                                       var5 = var2;
                                       var6 = var1;
                                    } else {
                                       var10001 = var2;
                                       var3 = var10002;
                                       if (var10002 <= var1) {
                                          a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                          return;
                                       }

                                       var5 = var2;
                                       var6 = var1;
                                    }

                                    while(true) {
                                       var9 = var5[var6];
                                       switch(var1 % 5) {
                                       case 0:
                                          var10 = 53;
                                          break;
                                       case 1:
                                          var10 = 22;
                                          break;
                                       case 2:
                                          var10 = 36;
                                          break;
                                       case 3:
                                          var10 = 117;
                                          break;
                                       default:
                                          var10 = 57;
                                       }

                                       var5[var6] = (char)(var9 ^ var10);
                                       ++var1;
                                       if (var3 == 0) {
                                          var6 = var3;
                                          var5 = var10001;
                                       } else {
                                          if (var3 <= var1) {
                                             a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                             return;
                                          }

                                          var5 = var10001;
                                          var6 = var1;
                                       }
                                    }
                                 }

                                 var8 = var10004;
                                 var10006 = var1;
                                 var10007 = var10004[var1];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10008 = 53;
                                    break;
                                 case 1:
                                    var10008 = 22;
                                    break;
                                 case 2:
                                    var10008 = 36;
                                    break;
                                 case 3:
                                    var10008 = 117;
                                    break;
                                 default:
                                    var10008 = 57;
                                 }
                              }
                           }
                        }
                     }

                     var8 = var10004;
                     var10006 = var1;
                     var10007 = var10004[var1];
                     switch(var1 % 5) {
                     case 0:
                        var10008 = 53;
                        break;
                     case 1:
                        var10008 = 22;
                        break;
                     case 2:
                        var10008 = 36;
                        break;
                     case 3:
                        var10008 = 117;
                        break;
                     default:
                        var10008 = 57;
                     }
                  }
               }
            }
         }

         var8 = var10003;
         var10006 = var1;
         var10007 = var10003[var1];
         switch(var1 % 5) {
         case 0:
            var10008 = 53;
            break;
         case 1:
            var10008 = 22;
            break;
         case 2:
            var10008 = 36;
            break;
         case 3:
            var10008 = 117;
            break;
         default:
            var10008 = 57;
         }
      }

      while(true) {
         while(true) {
            var8[var10006] = (char)(var10007 ^ var10008);
            ++var1;
            if (var6 == 0) {
               var10006 = var6;
               var8 = var10004;
               var10007 = var10004[var6];
               switch(var1 % 5) {
               case 0:
                  var10008 = 53;
                  break;
               case 1:
                  var10008 = 22;
                  break;
               case 2:
                  var10008 = 36;
                  break;
               case 3:
                  var10008 = 117;
                  break;
               default:
                  var10008 = 57;
               }
            } else {
               if (var6 <= var1) {
                  label333: {
                     var10000[1] = (new String(var10004)).intern();
                     var10003 = "}\u007fPXkTbAO\u0019".toCharArray();
                     var10005 = var10003.length;
                     var1 = 0;
                     var10004 = var10003;
                     var6 = var10005;
                     if (var10005 <= 1) {
                        var8 = var10003;
                        var10006 = var1;
                     } else {
                        var10004 = var10003;
                        var6 = var10005;
                        if (var10005 <= var1) {
                           break label333;
                        }

                        var8 = var10003;
                        var10006 = var1;
                     }

                     while(true) {
                        var10007 = var8[var10006];
                        switch(var1 % 5) {
                        case 0:
                           var10008 = 53;
                           break;
                        case 1:
                           var10008 = 22;
                           break;
                        case 2:
                           var10008 = 36;
                           break;
                        case 3:
                           var10008 = 117;
                           break;
                        default:
                           var10008 = 57;
                        }

                        var8[var10006] = (char)(var10007 ^ var10008);
                        ++var1;
                        if (var6 == 0) {
                           var10006 = var6;
                           var8 = var10004;
                        } else {
                           if (var6 <= var1) {
                              break;
                           }

                           var8 = var10004;
                           var10006 = var1;
                        }
                     }
                  }

                  var10000[2] = (new String(var10004)).intern();
                  var10003 = "gcJ\u001bP[q\u0004\u0016XV~AX\\C\u007fG\u0001PZx\n[\u0017".toCharArray();
                  var10005 = var10003.length;
                  var1 = 0;
                  var10004 = var10003;
                  var6 = var10005;
                  if (var10005 <= 1) {
                     var8 = var10003;
                     var10006 = var1;
                     var10007 = var10003[var1];
                     switch(var1 % 5) {
                     case 0:
                        var10008 = 53;
                        break;
                     case 1:
                        var10008 = 22;
                        break;
                     case 2:
                        var10008 = 36;
                        break;
                     case 3:
                        var10008 = 117;
                        break;
                     default:
                        var10008 = 57;
                     }
                  } else {
                     var10004 = var10003;
                     var6 = var10005;
                     if (var10005 <= var1) {
                        label377: {
                           var10000[3] = (new String(var10003)).intern();
                           var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~K\u0000M\u0015uE\u0016QP,".toCharArray();
                           var10005 = var10003.length;
                           var1 = 0;
                           var10004 = var10003;
                           var6 = var10005;
                           if (var10005 <= 1) {
                              var8 = var10003;
                              var10006 = var1;
                           } else {
                              var10004 = var10003;
                              var6 = var10005;
                              if (var10005 <= var1) {
                                 break label377;
                              }

                              var8 = var10003;
                              var10006 = var1;
                           }

                           while(true) {
                              var10007 = var8[var10006];
                              switch(var1 % 5) {
                              case 0:
                                 var10008 = 53;
                                 break;
                              case 1:
                                 var10008 = 22;
                                 break;
                              case 2:
                                 var10008 = 36;
                                 break;
                              case 3:
                                 var10008 = 117;
                                 break;
                              default:
                                 var10008 = 57;
                              }

                              var8[var10006] = (char)(var10007 ^ var10008);
                              ++var1;
                              if (var6 == 0) {
                                 var10006 = var6;
                                 var8 = var10004;
                              } else {
                                 if (var6 <= var1) {
                                    break;
                                 }

                                 var8 = var10004;
                                 var10006 = var1;
                              }
                           }
                        }

                        var10000[4] = (new String(var10004)).intern();
                        var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~\u0004\u0016XV~AO".toCharArray();
                        var10005 = var10003.length;
                        var1 = 0;
                        var10004 = var10003;
                        var6 = var10005;
                        if (var10005 <= 1) {
                           var8 = var10003;
                           var10006 = var1;
                           var10007 = var10003[var1];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        } else {
                           var10004 = var10003;
                           var6 = var10005;
                           if (var10005 <= var1) {
                              label445: {
                                 var10000[5] = (new String(var10003)).intern();
                                 var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                 var10005 = var10003.length;
                                 var1 = 0;
                                 var10004 = var10003;
                                 var6 = var10005;
                                 if (var10005 <= 1) {
                                    var8 = var10003;
                                    var10006 = var1;
                                 } else {
                                    var10004 = var10003;
                                    var6 = var10005;
                                    if (var10005 <= var1) {
                                       break label445;
                                    }

                                    var8 = var10003;
                                    var10006 = var1;
                                 }

                                 while(true) {
                                    var10007 = var8[var10006];
                                    switch(var1 % 5) {
                                    case 0:
                                       var10008 = 53;
                                       break;
                                    case 1:
                                       var10008 = 22;
                                       break;
                                    case 2:
                                       var10008 = 36;
                                       break;
                                    case 3:
                                       var10008 = 117;
                                       break;
                                    default:
                                       var10008 = 57;
                                    }

                                    var8[var10006] = (char)(var10007 ^ var10008);
                                    ++var1;
                                    if (var6 == 0) {
                                       var10006 = var6;
                                       var8 = var10004;
                                    } else {
                                       if (var6 <= var1) {
                                          break;
                                       }

                                       var8 = var10004;
                                       var10006 = var1;
                                    }
                                 }
                              }

                              var10000[6] = (new String(var10004)).intern();
                              b = var10000;
                              var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                              var10002 = var2.length;
                              var1 = 0;
                              var10001 = var2;
                              var3 = var10002;
                              if (var10002 <= 1) {
                                 var5 = var2;
                                 var6 = var1;
                              } else {
                                 var10001 = var2;
                                 var3 = var10002;
                                 if (var10002 <= var1) {
                                    a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                    return;
                                 }

                                 var5 = var2;
                                 var6 = var1;
                              }

                              while(true) {
                                 var9 = var5[var6];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10 = 53;
                                    break;
                                 case 1:
                                    var10 = 22;
                                    break;
                                 case 2:
                                    var10 = 36;
                                    break;
                                 case 3:
                                    var10 = 117;
                                    break;
                                 default:
                                    var10 = 57;
                                 }

                                 var5[var6] = (char)(var9 ^ var10);
                                 ++var1;
                                 if (var3 == 0) {
                                    var6 = var3;
                                    var5 = var10001;
                                 } else {
                                    if (var3 <= var1) {
                                       a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                       return;
                                    }

                                    var5 = var10001;
                                    var6 = var1;
                                 }
                              }
                           }

                           var8 = var10003;
                           var10006 = var1;
                           var10007 = var10003[var1];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        }

                        while(true) {
                           while(true) {
                              var8[var10006] = (char)(var10007 ^ var10008);
                              ++var1;
                              if (var6 == 0) {
                                 var10006 = var6;
                                 var8 = var10004;
                                 var10007 = var10004[var6];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10008 = 53;
                                    break;
                                 case 1:
                                    var10008 = 22;
                                    break;
                                 case 2:
                                    var10008 = 36;
                                    break;
                                 case 3:
                                    var10008 = 117;
                                    break;
                                 default:
                                    var10008 = 57;
                                 }
                              } else {
                                 if (var6 <= var1) {
                                    label553: {
                                       var10000[5] = (new String(var10004)).intern();
                                       var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                       var10005 = var10003.length;
                                       var1 = 0;
                                       var10004 = var10003;
                                       var6 = var10005;
                                       if (var10005 <= 1) {
                                          var8 = var10003;
                                          var10006 = var1;
                                       } else {
                                          var10004 = var10003;
                                          var6 = var10005;
                                          if (var10005 <= var1) {
                                             break label553;
                                          }

                                          var8 = var10003;
                                          var10006 = var1;
                                       }

                                       while(true) {
                                          var10007 = var8[var10006];
                                          switch(var1 % 5) {
                                          case 0:
                                             var10008 = 53;
                                             break;
                                          case 1:
                                             var10008 = 22;
                                             break;
                                          case 2:
                                             var10008 = 36;
                                             break;
                                          case 3:
                                             var10008 = 117;
                                             break;
                                          default:
                                             var10008 = 57;
                                          }

                                          var8[var10006] = (char)(var10007 ^ var10008);
                                          ++var1;
                                          if (var6 == 0) {
                                             var10006 = var6;
                                             var8 = var10004;
                                          } else {
                                             if (var6 <= var1) {
                                                break;
                                             }

                                             var8 = var10004;
                                             var10006 = var1;
                                          }
                                       }
                                    }

                                    var10000[6] = (new String(var10004)).intern();
                                    b = var10000;
                                    var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                                    var10002 = var2.length;
                                    var1 = 0;
                                    var10001 = var2;
                                    var3 = var10002;
                                    if (var10002 <= 1) {
                                       var5 = var2;
                                       var6 = var1;
                                    } else {
                                       var10001 = var2;
                                       var3 = var10002;
                                       if (var10002 <= var1) {
                                          a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                          return;
                                       }

                                       var5 = var2;
                                       var6 = var1;
                                    }

                                    while(true) {
                                       var9 = var5[var6];
                                       switch(var1 % 5) {
                                       case 0:
                                          var10 = 53;
                                          break;
                                       case 1:
                                          var10 = 22;
                                          break;
                                       case 2:
                                          var10 = 36;
                                          break;
                                       case 3:
                                          var10 = 117;
                                          break;
                                       default:
                                          var10 = 57;
                                       }

                                       var5[var6] = (char)(var9 ^ var10);
                                       ++var1;
                                       if (var3 == 0) {
                                          var6 = var3;
                                          var5 = var10001;
                                       } else {
                                          if (var3 <= var1) {
                                             a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                             return;
                                          }

                                          var5 = var10001;
                                          var6 = var1;
                                       }
                                    }
                                 }

                                 var8 = var10004;
                                 var10006 = var1;
                                 var10007 = var10004[var1];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10008 = 53;
                                    break;
                                 case 1:
                                    var10008 = 22;
                                    break;
                                 case 2:
                                    var10008 = 36;
                                    break;
                                 case 3:
                                    var10008 = 117;
                                    break;
                                 default:
                                    var10008 = 57;
                                 }
                              }
                           }
                        }
                     }

                     var8 = var10003;
                     var10006 = var1;
                     var10007 = var10003[var1];
                     switch(var1 % 5) {
                     case 0:
                        var10008 = 53;
                        break;
                     case 1:
                        var10008 = 22;
                        break;
                     case 2:
                        var10008 = 36;
                        break;
                     case 3:
                        var10008 = 117;
                        break;
                     default:
                        var10008 = 57;
                     }
                  }

                  while(true) {
                     while(true) {
                        var8[var10006] = (char)(var10007 ^ var10008);
                        ++var1;
                        if (var6 == 0) {
                           var10006 = var6;
                           var8 = var10004;
                           var10007 = var10004[var6];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        } else {
                           if (var6 <= var1) {
                              label172: {
                                 var10000[3] = (new String(var10004)).intern();
                                 var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~K\u0000M\u0015uE\u0016QP,".toCharArray();
                                 var10005 = var10003.length;
                                 var1 = 0;
                                 var10004 = var10003;
                                 var6 = var10005;
                                 if (var10005 <= 1) {
                                    var8 = var10003;
                                    var10006 = var1;
                                 } else {
                                    var10004 = var10003;
                                    var6 = var10005;
                                    if (var10005 <= var1) {
                                       break label172;
                                    }

                                    var8 = var10003;
                                    var10006 = var1;
                                 }

                                 while(true) {
                                    var10007 = var8[var10006];
                                    switch(var1 % 5) {
                                    case 0:
                                       var10008 = 53;
                                       break;
                                    case 1:
                                       var10008 = 22;
                                       break;
                                    case 2:
                                       var10008 = 36;
                                       break;
                                    case 3:
                                       var10008 = 117;
                                       break;
                                    default:
                                       var10008 = 57;
                                    }

                                    var8[var10006] = (char)(var10007 ^ var10008);
                                    ++var1;
                                    if (var6 == 0) {
                                       var10006 = var6;
                                       var8 = var10004;
                                    } else {
                                       if (var6 <= var1) {
                                          break;
                                       }

                                       var8 = var10004;
                                       var10006 = var1;
                                    }
                                 }
                              }

                              var10000[4] = (new String(var10004)).intern();
                              var10003 = "S\u007fF]\r\u0007?\u0004\u0002PA~\u0004\u0016XV~AO".toCharArray();
                              var10005 = var10003.length;
                              var1 = 0;
                              var10004 = var10003;
                              var6 = var10005;
                              if (var10005 <= 1) {
                                 var8 = var10003;
                                 var10006 = var1;
                                 var10007 = var10003[var1];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10008 = 53;
                                    break;
                                 case 1:
                                    var10008 = 22;
                                    break;
                                 case 2:
                                    var10008 = 36;
                                    break;
                                 case 3:
                                    var10008 = 117;
                                    break;
                                 default:
                                    var10008 = 57;
                                 }
                              } else {
                                 var10004 = var10003;
                                 var6 = var10005;
                                 if (var10005 <= var1) {
                                    label216: {
                                       var10000[5] = (new String(var10003)).intern();
                                       var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                       var10005 = var10003.length;
                                       var1 = 0;
                                       var10004 = var10003;
                                       var6 = var10005;
                                       if (var10005 <= 1) {
                                          var8 = var10003;
                                          var10006 = var1;
                                       } else {
                                          var10004 = var10003;
                                          var6 = var10005;
                                          if (var10005 <= var1) {
                                             break label216;
                                          }

                                          var8 = var10003;
                                          var10006 = var1;
                                       }

                                       while(true) {
                                          var10007 = var8[var10006];
                                          switch(var1 % 5) {
                                          case 0:
                                             var10008 = 53;
                                             break;
                                          case 1:
                                             var10008 = 22;
                                             break;
                                          case 2:
                                             var10008 = 36;
                                             break;
                                          case 3:
                                             var10008 = 117;
                                             break;
                                          default:
                                             var10008 = 57;
                                          }

                                          var8[var10006] = (char)(var10007 ^ var10008);
                                          ++var1;
                                          if (var6 == 0) {
                                             var10006 = var6;
                                             var8 = var10004;
                                          } else {
                                             if (var6 <= var1) {
                                                break;
                                             }

                                             var8 = var10004;
                                             var10006 = var1;
                                          }
                                       }
                                    }

                                    var10000[6] = (new String(var10004)).intern();
                                    b = var10000;
                                    var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                                    var10002 = var2.length;
                                    var1 = 0;
                                    var10001 = var2;
                                    var3 = var10002;
                                    if (var10002 <= 1) {
                                       var5 = var2;
                                       var6 = var1;
                                    } else {
                                       var10001 = var2;
                                       var3 = var10002;
                                       if (var10002 <= var1) {
                                          a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                          return;
                                       }

                                       var5 = var2;
                                       var6 = var1;
                                    }

                                    while(true) {
                                       var9 = var5[var6];
                                       switch(var1 % 5) {
                                       case 0:
                                          var10 = 53;
                                          break;
                                       case 1:
                                          var10 = 22;
                                          break;
                                       case 2:
                                          var10 = 36;
                                          break;
                                       case 3:
                                          var10 = 117;
                                          break;
                                       default:
                                          var10 = 57;
                                       }

                                       var5[var6] = (char)(var9 ^ var10);
                                       ++var1;
                                       if (var3 == 0) {
                                          var6 = var3;
                                          var5 = var10001;
                                       } else {
                                          if (var3 <= var1) {
                                             a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                             return;
                                          }

                                          var5 = var10001;
                                          var6 = var1;
                                       }
                                    }
                                 }

                                 var8 = var10003;
                                 var10006 = var1;
                                 var10007 = var10003[var1];
                                 switch(var1 % 5) {
                                 case 0:
                                    var10008 = 53;
                                    break;
                                 case 1:
                                    var10008 = 22;
                                    break;
                                 case 2:
                                    var10008 = 36;
                                    break;
                                 case 3:
                                    var10008 = 117;
                                    break;
                                 default:
                                    var10008 = 57;
                                 }
                              }

                              while(true) {
                                 while(true) {
                                    var8[var10006] = (char)(var10007 ^ var10008);
                                    ++var1;
                                    if (var6 == 0) {
                                       var10006 = var6;
                                       var8 = var10004;
                                       var10007 = var10004[var6];
                                       switch(var1 % 5) {
                                       case 0:
                                          var10008 = 53;
                                          break;
                                       case 1:
                                          var10008 = 22;
                                          break;
                                       case 2:
                                          var10008 = 36;
                                          break;
                                       case 3:
                                          var10008 = 117;
                                          break;
                                       default:
                                          var10008 = 57;
                                       }
                                    } else {
                                       if (var6 <= var1) {
                                          label136: {
                                             var10000[5] = (new String(var10004)).intern();
                                             var10003 = "bwM\u0001P[q\u0004@\u0019FsG\u001aWQe\u0004\u0001V\u0015zA\u0001\u0019ZcVU\\[bV\u001c\\F6A\rI\\dA[\u0017\u001b".toCharArray();
                                             var10005 = var10003.length;
                                             var1 = 0;
                                             var10004 = var10003;
                                             var6 = var10005;
                                             if (var10005 <= 1) {
                                                var8 = var10003;
                                                var10006 = var1;
                                             } else {
                                                var10004 = var10003;
                                                var6 = var10005;
                                                if (var10005 <= var1) {
                                                   break label136;
                                                }

                                                var8 = var10003;
                                                var10006 = var1;
                                             }

                                             while(true) {
                                                var10007 = var8[var10006];
                                                switch(var1 % 5) {
                                                case 0:
                                                   var10008 = 53;
                                                   break;
                                                case 1:
                                                   var10008 = 22;
                                                   break;
                                                case 2:
                                                   var10008 = 36;
                                                   break;
                                                case 3:
                                                   var10008 = 117;
                                                   break;
                                                default:
                                                   var10008 = 57;
                                                }

                                                var8[var10006] = (char)(var10007 ^ var10008);
                                                ++var1;
                                                if (var6 == 0) {
                                                   var10006 = var6;
                                                   var8 = var10004;
                                                } else {
                                                   if (var6 <= var1) {
                                                      break;
                                                   }

                                                   var8 = var10004;
                                                   var10006 = var1;
                                                }
                                             }
                                          }

                                          var10000[6] = (new String(var10004)).intern();
                                          b = var10000;
                                          var2 = "s\u007fF\u001aWTuG\u001c".toCharArray();
                                          var10002 = var2.length;
                                          var1 = 0;
                                          var10001 = var2;
                                          var3 = var10002;
                                          if (var10002 <= 1) {
                                             var5 = var2;
                                             var6 = var1;
                                          } else {
                                             var10001 = var2;
                                             var3 = var10002;
                                             if (var10002 <= var1) {
                                                a = d.a((new String(var2)).intern(), 10, 2L, TimeUnit.SECONDS);
                                                return;
                                             }

                                             var5 = var2;
                                             var6 = var1;
                                          }

                                          while(true) {
                                             var9 = var5[var6];
                                             switch(var1 % 5) {
                                             case 0:
                                                var10 = 53;
                                                break;
                                             case 1:
                                                var10 = 22;
                                                break;
                                             case 2:
                                                var10 = 36;
                                                break;
                                             case 3:
                                                var10 = 117;
                                                break;
                                             default:
                                                var10 = 57;
                                             }

                                             var5[var6] = (char)(var9 ^ var10);
                                             ++var1;
                                             if (var3 == 0) {
                                                var6 = var3;
                                                var5 = var10001;
                                             } else {
                                                if (var3 <= var1) {
                                                   a = d.a((new String(var10001)).intern(), 10, 2L, TimeUnit.SECONDS);
                                                   return;
                                                }

                                                var5 = var10001;
                                                var6 = var1;
                                             }
                                          }
                                       }

                                       var8 = var10004;
                                       var10006 = var1;
                                       var10007 = var10004[var1];
                                       switch(var1 % 5) {
                                       case 0:
                                          var10008 = 53;
                                          break;
                                       case 1:
                                          var10008 = 22;
                                          break;
                                       case 2:
                                          var10008 = 36;
                                          break;
                                       case 3:
                                          var10008 = 117;
                                          break;
                                       default:
                                          var10008 = 57;
                                       }
                                    }
                                 }
                              }
                           }

                           var8 = var10004;
                           var10006 = var1;
                           var10007 = var10004[var1];
                           switch(var1 % 5) {
                           case 0:
                              var10008 = 53;
                              break;
                           case 1:
                              var10008 = 22;
                              break;
                           case 2:
                              var10008 = 36;
                              break;
                           case 3:
                              var10008 = 117;
                              break;
                           default:
                              var10008 = 57;
                           }
                        }
                     }
                  }
               }

               var8 = var10004;
               var10006 = var1;
               var10007 = var10004[var1];
               switch(var1 % 5) {
               case 0:
                  var10008 = 53;
                  break;
               case 1:
                  var10008 = 22;
                  break;
               case 2:
                  var10008 = 36;
                  break;
               case 3:
                  var10008 = 117;
                  break;
               default:
                  var10008 = 57;
               }
            }
         }
      }
   }
}
