public class a6 {
   public static void main(String[] param0) throws Exception {
      // $FF: Couldn't be decompiled
   }
}
