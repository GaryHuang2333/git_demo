class a_ extends RuntimeException {
   private static final long serialVersionUID = -7454219131982518216L;
   final bc a;

   a_(bc var1) {
      this.a = var1;
   }
}
