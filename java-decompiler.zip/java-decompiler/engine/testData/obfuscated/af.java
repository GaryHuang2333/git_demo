// $FF: synthetic class
class af {
}
