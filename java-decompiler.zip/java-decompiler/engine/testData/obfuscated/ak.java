public interface ak {
   String a();

   String b();

   String c();

   double d();

   Double e();
}
