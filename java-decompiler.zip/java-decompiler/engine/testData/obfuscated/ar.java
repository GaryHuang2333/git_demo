public class ar extends ap {
   private final String d;
   private final double e;

   public ar(String var1, String var2, String var3, double var4) {
      super(var1, var2);
      this.d = var3;
      this.e = var4;
   }

   public String c() {
      return this.d;
   }

   public double d() {
      return this.e;
   }

   public Double e() {
      return null;
   }
}
