class au extends ap {
   private long d;
   private long e;
   final an f;

   au(an var1, String var2, String var3) {
      super(var2, var3);
      this.f = var1;
      this.d = 0L;
      this.e = 0L;
   }

   public double d() {
      // $FF: Couldn't be decompiled
   }

   public String c() {
      return "%";
   }

   public Double e() {
      return 100.0D;
   }
}
