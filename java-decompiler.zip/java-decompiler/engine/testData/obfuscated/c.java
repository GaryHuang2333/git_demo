@aa(
   a = {ac.class}
)
public class c implements ac {
   public void a() throws Exception {
      d.b();
   }
}
