public interface q {
   void a(p var1);
}
