package ext;

// companion class for pkg/TestShadowing.java
public class Shadow {
  public static class B { }
}