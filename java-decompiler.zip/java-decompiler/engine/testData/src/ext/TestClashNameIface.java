package ext;
interface TestClashNameIface {
  public void foo();
}
