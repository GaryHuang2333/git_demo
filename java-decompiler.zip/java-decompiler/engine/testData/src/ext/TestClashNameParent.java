package ext;

public class TestClashNameParent {
  int SharedName3 = 0;
}
