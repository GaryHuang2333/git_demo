package pkg;

// companion class for pkg/TestShadowing.java
public class Shadow { }