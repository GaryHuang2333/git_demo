package pkg

trait TestGroovyTrait {
  def myField = 42
  def myMethod() {
    42
  }
}