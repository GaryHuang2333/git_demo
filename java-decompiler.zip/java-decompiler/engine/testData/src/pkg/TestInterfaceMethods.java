package pkg;

public interface TestInterfaceMethods {
  static void staticMethod() {}
  default void defaultMethod() {}
}