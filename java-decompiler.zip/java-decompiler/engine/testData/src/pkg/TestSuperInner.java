package pkg;

class TestSuperInner extends TestSuperInnerBase {
  protected abstract class Inner2 extends Inner { }
}